import { ScheduleItem, NoteItem, UserProfile } from '../types';
import { v4 as uuidv4 } from 'uuid';

const STORAGE_KEYS = {
  SCHEDULE: 'timeflow_schedule_v1',
  NOTES: 'timeflow_notes_v1',
  PROFILE: 'timeflow_profile_v1',
};

// --- Scheduler Service ---

export const getSchedule = async (): Promise<ScheduleItem[]> => {
  await new Promise(resolve => setTimeout(resolve, 300));
  const data = localStorage.getItem(STORAGE_KEYS.SCHEDULE);
  return data ? JSON.parse(data) : [];
};

export const addScheduleItem = async (item: Omit<ScheduleItem, '_id'>): Promise<ScheduleItem> => {
  const current = await getSchedule();
  const newItem: ScheduleItem = { ...item, _id: uuidv4() };
  const updated = [...current, newItem];
  updated.sort((a, b) => a.startTime.localeCompare(b.startTime));
  localStorage.setItem(STORAGE_KEYS.SCHEDULE, JSON.stringify(updated));
  return newItem;
};

export const deleteScheduleItem = async (id: string): Promise<void> => {
  const current = await getSchedule();
  const updated = current.filter(i => i._id !== id);
  localStorage.setItem(STORAGE_KEYS.SCHEDULE, JSON.stringify(updated));
};

// --- Notes Service ---

export const getNotes = async (): Promise<NoteItem[]> => {
  await new Promise(resolve => setTimeout(resolve, 300));
  const data = localStorage.getItem(STORAGE_KEYS.NOTES);
  return data ? JSON.parse(data) : [];
};

export const addNote = async (note: Omit<NoteItem, '_id' | 'createdAt'>): Promise<NoteItem> => {
  const current = await getNotes();
  const newNote: NoteItem = { 
    ...note, 
    _id: uuidv4(),
    createdAt: Date.now()
  };
  const updated = [newNote, ...current];
  localStorage.setItem(STORAGE_KEYS.NOTES, JSON.stringify(updated));
  return newNote;
};

export const deleteNote = async (id: string): Promise<void> => {
  const current = await getNotes();
  const updated = current.filter(n => n._id !== id);
  localStorage.setItem(STORAGE_KEYS.NOTES, JSON.stringify(updated));
};

// --- User Profile / Settings Service ---

export const getUserProfile = async (): Promise<UserProfile> => {
  // No delay for profile to avoid flickering background
  const data = localStorage.getItem(STORAGE_KEYS.PROFILE);
  return data ? JSON.parse(data) : { name: 'Guest User', theme: 'neon' };
};

export const saveUserProfile = async (profile: UserProfile): Promise<UserProfile> => {
  localStorage.setItem(STORAGE_KEYS.PROFILE, JSON.stringify(profile));
  return profile;
};