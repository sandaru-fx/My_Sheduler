import React, { useState, useEffect } from 'react';
import { ViewMode, UserProfile } from './types';
import { getUserProfile } from './services/db';
import ThreeBackground from './components/ThreeBackground';
import Scheduler from './components/Scheduler';
import Notes from './components/Notes';
import Settings from './components/Settings';
import LoginPage from './components/LoginPage';
import LandingPage from './components/LandingPage';
import { LayoutDashboard, StickyNote, Menu, LogOut, Settings as SettingsIcon } from 'lucide-react';

const App: React.FC = () => {
  // Navigation State
  // 'landing' -> User sees Landing Page
  // 'login' -> User sees Login Form
  // 'app' -> User is authenticated and sees the main app
  const [currentView, setCurrentView] = useState<'landing' | 'login' | 'app'>('landing');
  
  const [view, setView] = useState<ViewMode>('scheduler');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [profile, setProfile] = useState<UserProfile>({ name: 'Guest', theme: 'neon' });
  const [loadingProfile, setLoadingProfile] = useState(true);

  useEffect(() => {
    // Load profile on start
    const load = async () => {
      const data = await getUserProfile();
      setProfile(data);
      setLoadingProfile(false);
    };
    load();
  }, []);

  const handleUpdateProfile = (newProfile: UserProfile) => {
    setProfile(newProfile);
  };

  const handleLoginSuccess = () => {
    setCurrentView('app');
  };
  
  const handleLogout = () => {
    setCurrentView('landing');
    setView('scheduler'); // Reset internal view
  };

  const NavItem = ({ mode, icon: Icon, label }: { mode: ViewMode; icon: any; label: string }) => (
    <button
      onClick={() => {
        setView(mode);
        setSidebarOpen(false); // Close mobile sidebar on select
      }}
      className={`flex items-center gap-3 w-full px-4 py-3 rounded-xl transition-all duration-300 ${
        view === mode 
          ? 'bg-gradient-to-r from-indigo-600 to-indigo-500 text-white shadow-lg shadow-indigo-500/30' 
          : 'text-gray-400 hover:text-white hover:bg-white/5'
      }`}
    >
      <Icon size={20} />
      <span className="font-semibold tracking-wide">{label}</span>
      {view === mode && <div className="ml-auto w-1.5 h-1.5 rounded-full bg-white shadow-[0_0_8px_white]" />}
    </button>
  );

  return (
    <div className={`relative w-full h-screen ${profile.theme === 'light' ? 'text-slate-800' : 'text-white'} overflow-hidden flex font-sans`}>
      {/* 3D Background with Dynamic Theme - Persistent across all views */}
      <ThreeBackground theme={profile.theme} />

      {/* --- Landing Page View --- */}
      {currentView === 'landing' && (
        <div className="absolute inset-0 z-50 bg-transparent">
          <LandingPage onGetStarted={() => setCurrentView('login')} />
        </div>
      )}

      {/* --- Login View --- */}
      {currentView === 'login' && (
        <LoginPage 
          onLogin={handleLoginSuccess} 
          onBack={() => setCurrentView('landing')}
        />
      )}

      {/* --- Main App View --- */}
      {currentView === 'app' && (
        <>
          {/* Sidebar Navigation */}
          <aside className={`
            fixed lg:relative z-50 h-full w-64 ${profile.theme === 'light' ? 'bg-white/80 border-slate-200' : 'bg-slate-900/90 border-white/10'} lg:bg-transparent backdrop-blur-xl border-r p-6 flex flex-col gap-8 transition-transform duration-300
            ${sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
          `}>
            <div className="flex items-center gap-3 px-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-indigo-500 to-pink-500 flex items-center justify-center shadow-lg shadow-indigo-500/20">
                <span className="font-bold text-lg text-white">T</span>
              </div>
              <h1 className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-indigo-400 to-pink-400">
                TimeFlow
              </h1>
            </div>

            {/* User Profile Mini Card */}
            <div className={`flex items-center gap-3 p-3 rounded-xl border ${profile.theme === 'light' ? 'bg-indigo-50 border-indigo-100' : 'bg-white/5 border-white/5'}`}>
              <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-purple-500 to-indigo-500 flex items-center justify-center text-white font-bold text-lg shadow-md">
                {profile.name.charAt(0).toUpperCase()}
              </div>
              <div className="overflow-hidden">
                <p className={`text-sm font-bold truncate ${profile.theme === 'light' ? 'text-slate-700' : 'text-white'}`}>{profile.name}</p>
                <p className="text-xs text-indigo-400 truncate capitalize">{profile.theme} Mode</p>
              </div>
            </div>

            <nav className="flex-1 space-y-2">
              <NavItem mode="scheduler" icon={LayoutDashboard} label="Scheduler" />
              <NavItem mode="notes" icon={StickyNote} label="My Notes" />
              <NavItem mode="settings" icon={SettingsIcon} label="Settings" />
            </nav>

            <div className="space-y-4">
              <button 
                onClick={handleLogout}
                className="flex items-center gap-3 w-full px-4 py-3 rounded-xl text-gray-400 hover:text-red-400 hover:bg-red-500/10 transition-all duration-300"
              >
                <LogOut size={20} />
                <span className="font-semibold tracking-wide">Sign Out</span>
              </button>
              
              <div className={`p-4 rounded-xl border ${profile.theme === 'light' ? 'bg-white/40 border-slate-200' : 'bg-white/5 border-white/5'}`}>
                <p className="text-xs text-gray-500 text-center leading-relaxed">
                  "The future depends on what you do today."
                </p>
              </div>
            </div>
          </aside>

          {/* Main Content Area */}
          <main className="flex-1 flex flex-col h-full relative z-10">
            {/* Mobile Header */}
            <header className={`lg:hidden h-16 flex items-center justify-between px-6 border-b backdrop-blur-md ${profile.theme === 'light' ? 'bg-white/50 border-slate-200 text-slate-800' : 'bg-slate-900/50 border-white/10 text-white'}`}>
              <span className="font-bold text-xl capitalize">
                {view === 'scheduler' ? 'Daily Plan' : view === 'notes' ? 'Notes' : 'Settings'}
              </span>
              <button onClick={() => setSidebarOpen(!sidebarOpen)} className="p-2">
                <Menu />
              </button>
            </header>

            {/* Content Container */}
            <div className="flex-1 p-4 lg:p-8 overflow-hidden">
              {view === 'scheduler' ? (
                <Scheduler />
              ) : view === 'notes' ? (
                <Notes />
              ) : (
                <Settings profile={profile} onUpdateProfile={handleUpdateProfile} />
              )}
            </div>
          </main>

          {/* Mobile Overlay */}
          {sidebarOpen && (
            <div 
              className="fixed inset-0 bg-black/60 z-40 lg:hidden backdrop-blur-sm"
              onClick={() => setSidebarOpen(false)}
            />
          )}
        </>
      )}
    </div>
  );
};

export default App;