import React from 'react';
import { Button } from './ui/Button';
import { ArrowRight, Layout, Zap, Palette, CheckCircle, Clock, Star, MousePointer2 } from 'lucide-react';

interface LandingPageProps {
  onGetStarted: () => void;
}

const LandingPage: React.FC<LandingPageProps> = ({ onGetStarted }) => {
  return (
    <div className="relative w-full h-full text-white overflow-y-auto overflow-x-hidden font-sans scroll-smooth">
      <style>{`
        @keyframes float {
          0% { transform: translateY(0px) rotateX(10deg) rotateY(10deg); }
          50% { transform: translateY(-20px) rotateX(5deg) rotateY(5deg); }
          100% { transform: translateY(0px) rotateX(10deg) rotateY(10deg); }
        }
        @keyframes float-delayed {
          0% { transform: translateY(0px) rotateX(5deg) rotateY(-10deg); }
          50% { transform: translateY(-15px) rotateX(10deg) rotateY(-5deg); }
          100% { transform: translateY(0px) rotateX(5deg) rotateY(-10deg); }
        }
        .animate-float { animation: float 6s ease-in-out infinite; }
        .animate-float-delayed { animation: float-delayed 7s ease-in-out infinite; }
        .perspective-1000 { perspective: 1000px; }
      `}</style>

      {/* Navbar */}
      <nav className="flex items-center justify-between px-6 md:px-12 py-6 max-w-7xl mx-auto animate-in slide-in-from-top duration-700">
        <div className="flex items-center gap-2">
           <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-pink-500 flex items-center justify-center shadow-lg shadow-indigo-500/20">
             <span className="font-bold text-xl text-white">T</span>
           </div>
           <span className="text-2xl font-bold tracking-tight">TimeFlow</span>
        </div>
        <div className="flex gap-4">
          <button onClick={onGetStarted} className="hidden md:block text-sm font-medium text-gray-300 hover:text-white transition-colors">Sign In</button>
          <Button onClick={onGetStarted} className="px-6 rounded-full">Get Started</Button>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="max-w-7xl mx-auto px-6 md:px-12 pt-10 pb-20 flex flex-col lg:flex-row items-center gap-16 min-h-[calc(100vh-100px)]">
        
        {/* Left Content */}
        <div className="flex-1 space-y-8 animate-in slide-in-from-left duration-1000 z-10">
           <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 text-sm font-medium backdrop-blur-md">
             <Star size={14} className="fill-indigo-500/20" />
             <span>The #1 Aesthetic Scheduler</span>
           </div>
           
           <h1 className="text-5xl md:text-7xl font-extrabold tracking-tight leading-[1.1]">
             Master Your Day <br/>
             <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 via-purple-400 to-pink-400">
               Design Your Destiny.
             </span>
           </h1>
           
           <p className="text-lg text-gray-300 max-w-xl leading-relaxed">
             Time is the only currency you can't save. Spend it wisely. 
             TimeFlow combines immersive 3D environments with powerful tools to help you sculpt your perfect day.
           </p>

           <div className="flex flex-col sm:flex-row gap-4 pt-4">
             <Button onClick={onGetStarted} className="h-14 px-8 text-lg bg-white text-indigo-950 hover:bg-gray-100 shadow-[0_0_20px_rgba(255,255,255,0.3)] hover:scale-105 transition-transform duration-300 rounded-full">
               Start Planning Free
             </Button>
             <Button onClick={onGetStarted} variant="secondary" className="h-14 px-8 text-lg rounded-full backdrop-blur-md">
               View Live Demo <ArrowRight className="ml-2 w-5 h-5" />
             </Button>
           </div>
           
           <div className="flex items-center gap-6 pt-6 text-sm text-gray-400 font-medium">
             <div className="flex items-center gap-2">
               <CheckCircle size={16} className="text-green-500" /> No Credit Card Required
             </div>
             <div className="flex items-center gap-2">
               <CheckCircle size={16} className="text-green-500" /> Instant Setup
             </div>
           </div>
        </div>

        {/* Right 3D Visuals */}
        <div className="flex-1 w-full relative h-[400px] lg:h-[600px] perspective-1000 flex items-center justify-center">
           {/* Decorative Glow */}
           <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-indigo-500/20 blur-[100px] rounded-full pointer-events-none" />

           {/* Floating Card 1 (Top Right) */}
           <div className="absolute top-10 right-0 md:right-10 w-80 p-6 bg-slate-800/40 backdrop-blur-xl border border-white/20 rounded-3xl shadow-2xl animate-float cursor-default hover:bg-slate-800/60 transition-colors">
              <div className="flex items-center justify-between mb-4">
                 <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-pink-500 to-purple-500 flex items-center justify-center text-white">
                        <Zap size={20} />
                    </div>
                    <div>
                        <h3 className="font-bold text-white">Deep Work</h3>
                        <p className="text-xs text-purple-300">High Priority</p>
                    </div>
                 </div>
                 <span className="text-xs font-mono bg-white/10 px-2 py-1 rounded text-white">2h 30m</span>
              </div>
              
              <div className="p-4 bg-black/20 rounded-xl border border-white/5 mb-2">
                 <p className="text-sm text-gray-200 italic font-medium">
                    "Chaos is just a schedule waiting to happen."
                 </p>
              </div>
              <div className="w-full bg-gray-700/50 rounded-full h-1.5 mt-2 overflow-hidden">
                  <div className="bg-pink-500 h-full w-2/3 rounded-full" />
              </div>
           </div>

           {/* Floating Card 2 (Bottom Left) */}
           <div className="absolute bottom-10 left-0 md:left-10 w-72 p-6 bg-slate-900/60 backdrop-blur-xl border border-indigo-500/30 rounded-3xl shadow-2xl animate-float-delayed z-20 hover:border-indigo-400 transition-colors">
              <div className="flex items-center gap-3 mb-4">
                 <div className="p-2 bg-indigo-500/20 rounded-lg text-indigo-400"><Clock size={24} /></div>
                 <div>
                   <h3 className="font-bold text-lg text-white">Next Task</h3>
                   <p className="text-xs text-gray-400">Starts in 5 mins</p>
                 </div>
              </div>
              <div className="space-y-3">
                  <div className="flex items-center gap-2 text-sm text-gray-300">
                      <div className="w-2 h-2 bg-green-400 rounded-full shadow-[0_0_5px_rgba(74,222,128,0.5)]" />
                      <span>Review project goals</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-300">
                      <div className="w-2 h-2 bg-indigo-400 rounded-full" />
                      <span>Design landing page</span>
                  </div>
              </div>
              <p className="text-xs text-gray-500 mt-4 border-t border-white/10 pt-3 italic">
                 "Time is the canvas of your life. Paint it with purpose."
              </p>
           </div>
        </div>
      </div>

      {/* Features Grid */}
      <div className="bg-slate-900/50 backdrop-blur-xl border-t border-white/5 py-24 relative z-10">
        <div className="max-w-7xl mx-auto px-6 md:px-12">
           <div className="text-center mb-16">
             <h2 className="text-3xl md:text-4xl font-bold mb-4">Why Choose TimeFlow?</h2>
             <p className="text-gray-400 max-w-2xl mx-auto">
               We don't just help you manage time. We help you enjoy it. 
               Experience a scheduler that looks as good as it works.
             </p>
           </div>

           <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <FeatureCard 
                icon={<Layout className="text-indigo-400" />}
                title="Visual Blocking"
                desc="Drag and drop your day into clarity. See your time gaps and opportunities instantly."
              />
              <FeatureCard 
                icon={<Palette className="text-pink-400" />}
                title="Atmospheric Themes"
                desc="Immerse yourself. Choose from Neon, Snow, Flowers, or Space to match your flow state."
              />
              <FeatureCard 
                icon={<MousePointer2 className="text-yellow-400" />}
                title="Smart Notes"
                desc="Link your thoughts to your timeline. Highlight important ideas with color tags."
              />
           </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="border-t border-white/5 bg-slate-900/80 py-12 text-center text-gray-500 text-sm">
         <p>© {new Date().getFullYear()} TimeFlow. Built with ❤️ for productive people.</p>
      </footer>
    </div>
  );
};

const FeatureCard = ({ icon, title, desc }: any) => (
  <div className="group p-8 rounded-3xl bg-white/5 border border-white/5 hover:bg-white/10 hover:border-indigo-500/30 transition-all duration-500 hover:-translate-y-2 cursor-default">
    <div className="w-14 h-14 rounded-2xl bg-slate-900 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform border border-white/10 shadow-lg">
      {icon}
    </div>
    <h3 className="text-xl font-bold mb-3 text-white group-hover:text-indigo-300 transition-colors">{title}</h3>
    <p className="text-gray-400 leading-relaxed group-hover:text-gray-300">
      {desc}
    </p>
  </div>
);

export default LandingPage;