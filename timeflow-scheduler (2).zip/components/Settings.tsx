import React, { useState } from 'react';
import { UserProfile, ThemeVariant } from '../types';
import { saveUserProfile } from '../services/db';
import { Button } from './ui/Button';
import { Input } from './ui/Input';
import { User, Palette, Check, Snowflake, Sun, Moon, Sparkles, Flower2 } from 'lucide-react';

interface SettingsProps {
  profile: UserProfile;
  onUpdateProfile: (profile: UserProfile) => void;
}

const ThemeCard = ({ 
  theme, 
  current, 
  onClick, 
  icon: Icon, 
  label 
}: { 
  theme: ThemeVariant; 
  current: ThemeVariant; 
  onClick: () => void; 
  icon: any; 
  label: string; 
}) => {
  const isSelected = theme === current;
  return (
    <button
      onClick={onClick}
      className={`relative group flex flex-col items-center justify-center p-4 rounded-xl border transition-all duration-300 ${
        isSelected 
          ? 'bg-indigo-500/20 border-indigo-500 shadow-[0_0_15px_rgba(99,102,241,0.3)]' 
          : 'bg-slate-800/50 border-white/10 hover:bg-slate-800 hover:border-white/30'
      }`}
    >
      <div className={`p-3 rounded-full mb-3 ${isSelected ? 'bg-indigo-500 text-white' : 'bg-white/5 text-gray-400 group-hover:text-white'}`}>
        <Icon size={24} />
      </div>
      <span className={`text-sm font-medium ${isSelected ? 'text-white' : 'text-gray-400 group-hover:text-white'}`}>
        {label}
      </span>
      {isSelected && (
        <div className="absolute top-2 right-2 w-5 h-5 bg-indigo-500 rounded-full flex items-center justify-center">
          <Check size={12} className="text-white" />
        </div>
      )}
    </button>
  );
};

const Settings: React.FC<SettingsProps> = ({ profile, onUpdateProfile }) => {
  const [name, setName] = useState(profile.name);
  const [theme, setTheme] = useState<ThemeVariant>(profile.theme);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const handleSave = async () => {
    if (!name.trim()) {
        setError("Name cannot be empty");
        return;
    }

    setSaving(true);
    const newProfile = { name, theme };
    await saveUserProfile(newProfile);
    onUpdateProfile(newProfile);
    // Simulate slight delay for feedback
    setTimeout(() => setSaving(false), 500);
  };

  return (
    <div className="h-full flex flex-col gap-6 overflow-y-auto pr-2">
      <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-8 shadow-2xl">
        <h2 className="text-2xl font-bold mb-6 flex items-center gap-2 border-b border-white/10 pb-4">
          <User className="text-indigo-400" /> User Profile
        </h2>
        
        <div className="max-w-md">
          <Input 
            label="Display Name" 
            value={name} 
            onChange={(e) => {
                setName(e.target.value);
                setError('');
            }}
            placeholder="Enter your name"
            startIcon={<User size={18} />}
            error={error}
          />
        </div>
      </div>

      <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-8 shadow-2xl">
        <h2 className="text-2xl font-bold mb-6 flex items-center gap-2 border-b border-white/10 pb-4">
          <Palette className="text-pink-400" /> Appearance & Atmosphere
        </h2>
        
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 mb-8">
          <ThemeCard 
            theme="neon" 
            current={theme} 
            onClick={() => setTheme('neon')} 
            icon={Moon} 
            label="Neon Night" 
          />
          <ThemeCard 
            theme="stars" 
            current={theme} 
            onClick={() => setTheme('stars')} 
            icon={Sparkles} 
            label="Starry Sky" 
          />
          <ThemeCard 
            theme="light" 
            current={theme} 
            onClick={() => setTheme('light')} 
            icon={Sun} 
            label="Light / Day" 
          />
          <ThemeCard 
            theme="snow" 
            current={theme} 
            onClick={() => setTheme('snow')} 
            icon={Snowflake} 
            label="Winter Snow" 
          />
          <ThemeCard 
            theme="flowers" 
            current={theme} 
            onClick={() => setTheme('flowers')} 
            icon={Flower2} 
            label="Spring Flora" 
          />
        </div>

        <div className="flex justify-end">
          <Button onClick={handleSave} isLoading={saving} className="px-8">
            Save Changes
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Settings;