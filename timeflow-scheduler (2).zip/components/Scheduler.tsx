import React, { useState, useEffect } from 'react';
import { ScheduleItem, COLORS } from '../types';
import { getSchedule, addScheduleItem, deleteScheduleItem } from '../services/db';
import { Button } from './ui/Button';
import { Input } from './ui/Input';
import { Trash2, Plus, Calendar } from 'lucide-react';

const Scheduler: React.FC = () => {
  const [items, setItems] = useState<ScheduleItem[]>([]);
  const [loading, setLoading] = useState(true);
  
  // Form State
  const [startTime, setStartTime] = useState('');
  const [endTime, setEndTime] = useState('');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [selectedColor, setSelectedColor] = useState(COLORS[0]);

  // Validation State
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  useEffect(() => {
    loadItems();
  }, []);

  const loadItems = async () => {
    setLoading(true);
    const data = await getSchedule();
    setItems(data);
    setLoading(false);
  };

  const validate = () => {
      const newErrors: { [key: string]: string } = {};
      let isValid = true;

      if (!startTime) {
          newErrors.startTime = "Required";
          isValid = false;
      }
      if (!endTime) {
          newErrors.endTime = "Required";
          isValid = false;
      }
      if (!title.trim()) {
          newErrors.title = "Task title is required";
          isValid = false;
      }

      if (startTime && endTime) {
          if (endTime <= startTime) {
              newErrors.endTime = "End time must be after start time";
              isValid = false;
          }
      }

      setErrors(newErrors);
      return isValid;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    await addScheduleItem({
      startTime,
      endTime,
      title,
      description,
      color: selectedColor,
      date: new Date().toISOString(),
    });

    setTitle('');
    setDescription('');
    setStartTime('');
    setEndTime('');
    setErrors({});
    loadItems();
  };

  const handleDelete = async (id: string) => {
    await deleteScheduleItem(id);
    loadItems();
  };

  const getDuration = (start: string, end: string) => {
    if(!start || !end) return '';
    const [h1, m1] = start.split(':').map(Number);
    const [h2, m2] = end.split(':').map(Number);
    let diff = (h2 * 60 + m2) - (h1 * 60 + m1);
    if (diff < 0) diff += 24 * 60;
    
    const hours = Math.floor(diff / 60);
    const mins = diff % 60;
    
    if (hours > 0 && mins > 0) return `${hours}h ${mins}m`;
    if (hours > 0) return `${hours}h`;
    return `${mins}m`;
  };

  return (
    <div className="flex flex-col lg:flex-row gap-6 h-full overflow-hidden">
      {/* Input Section */}
      <div className="w-full lg:w-1/3 bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 shadow-2xl overflow-y-auto">
        <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
          <Plus className="text-indigo-400" /> New Task
        </h2>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <Input 
              label="Start" 
              type="time" 
              value={startTime} 
              onChange={(e) => {
                  setStartTime(e.target.value);
                  if (errors.startTime) setErrors({...errors, startTime: ''});
                  if (errors.endTime) setErrors({...errors, endTime: ''});
              }} 
              error={errors.startTime}
            />
            <Input 
              label="End" 
              type="time" 
              value={endTime} 
              onChange={(e) => {
                  setEndTime(e.target.value);
                  if (errors.endTime) setErrors({...errors, endTime: ''});
              }} 
              error={errors.endTime}
            />
          </div>

          <Input 
            label="Work / Task" 
            placeholder="What are you doing?" 
            value={title} 
            onChange={(e) => {
                setTitle(e.target.value);
                if (errors.title) setErrors({...errors, title: ''});
            }} 
            error={errors.title}
          />
          
          <Input 
            label="Note (Optional)" 
            placeholder="Details..." 
            value={description} 
            onChange={(e) => setDescription(e.target.value)} 
          />

          <div className="space-y-2">
            <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Color Tag</label>
            <div className="flex gap-2">
              {COLORS.map((c) => (
                <button
                  key={c}
                  type="button"
                  className={`w-8 h-8 rounded-full ${c} transition-transform ${selectedColor === c ? 'scale-110 ring-2 ring-white' : 'opacity-60 hover:opacity-100 hover:scale-105'}`}
                  onClick={() => setSelectedColor(c)}
                />
              ))}
            </div>
          </div>

          <Button type="submit" className="w-full mt-4">
            Add to Schedule
          </Button>
        </form>
      </div>

      {/* Timeline Section */}
      <div className="w-full lg:w-2/3 bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-6 shadow-2xl overflow-hidden flex flex-col">
        <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
          <Calendar className="text-pink-400" /> Today's Timeline
        </h2>

        <div className="flex-1 overflow-y-auto pr-2 space-y-4 relative">
          <div className="absolute left-[85px] top-0 bottom-0 w-0.5 bg-white/10 -z-10" />

          {loading ? (
            <div className="text-center py-20 text-gray-400">Loading schedule...</div>
          ) : items.length === 0 ? (
            <div className="text-center py-20 text-gray-400">
              <p className="text-xl">Time is money.</p>
              <p className="text-sm mt-2">Add your first task to start tracking.</p>
            </div>
          ) : (
            items.map((item) => (
              <div key={item._id} className="flex group">
                {/* Time Column */}
                <div className="w-[80px] flex flex-col items-end mr-6 pt-1">
                  <span className="font-mono font-bold text-lg text-white">{item.startTime}</span>
                  <span className="text-xs text-gray-500 font-mono">{item.endTime}</span>
                  <span className="text-[10px] text-indigo-400 mt-1 bg-indigo-500/10 px-1.5 py-0.5 rounded">
                    {getDuration(item.startTime, item.endTime)}
                  </span>
                </div>

                {/* Card */}
                <div className="flex-1 pb-6 relative">
                  <div className={`absolute -left-[29px] top-3 w-3 h-3 rounded-full border-2 border-[#0f172a] ${item.color}`} />
                  
                  <div className="bg-slate-800/80 border border-white/5 hover:border-white/20 p-4 rounded-xl transition-all hover:translate-x-1 group-hover:shadow-lg group-hover:shadow-black/50">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="text-xl font-bold text-white mb-1">{item.title}</h3>
                        {item.description && (
                          <p className="text-gray-400 text-sm">{item.description}</p>
                        )}
                      </div>
                      <button 
                        onClick={() => handleDelete(item._id)}
                        className="opacity-0 group-hover:opacity-100 p-2 text-gray-500 hover:text-red-400 transition-opacity"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default Scheduler;