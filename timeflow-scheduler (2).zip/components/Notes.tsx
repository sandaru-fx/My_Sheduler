import React, { useState, useEffect } from 'react';
import { NoteItem, COLORS } from '../types';
import { getNotes, addNote, deleteNote } from '../services/db';
import { Button } from './ui/Button';
import { Input, TextArea } from './ui/Input';
import { StickyNote, Trash2, CalendarDays } from 'lucide-react';

const Notes: React.FC = () => {
  const [notes, setNotes] = useState<NoteItem[]>([]);
  const [loading, setLoading] = useState(true);
  
  const [topic, setTopic] = useState('');
  const [content, setContent] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [selectedColor, setSelectedColor] = useState(COLORS[1]); // Default purple

  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  useEffect(() => {
    loadNotes();
  }, []);

  const loadNotes = async () => {
    setLoading(true);
    const data = await getNotes();
    setNotes(data);
    setLoading(false);
  };

  const validate = () => {
      const newErrors: { [key: string]: string } = {};
      let isValid = true;
      
      if (!topic.trim()) {
          newErrors.topic = "Topic is required";
          isValid = false;
      }
      if (!date) {
          newErrors.date = "Date is required";
          isValid = false;
      }
      if (!content.trim()) {
          newErrors.content = "Content cannot be empty";
          isValid = false;
      }

      setErrors(newErrors);
      return isValid;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validate()) return;

    await addNote({
      topic,
      content,
      date,
      colorTag: selectedColor
    });

    setTopic('');
    setContent('');
    setErrors({});
    loadNotes();
  };

  const handleDelete = async (id: string) => {
    await deleteNote(id);
    loadNotes();
  };

  return (
    <div className="h-full flex flex-col gap-6">
      {/* Create Note Bar */}
      <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 shadow-xl">
        <form onSubmit={handleSubmit} className="flex flex-col md:flex-row gap-4 items-end">
          <div className="flex-1 w-full space-y-4">
             <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Input 
                  label="Topic / Title" 
                  value={topic} 
                  onChange={(e) => {
                      setTopic(e.target.value);
                      if(errors.topic) setErrors({...errors, topic: ''});
                  }}
                  placeholder="Important Meeting..."
                  error={errors.topic}
                />
                <Input 
                  label="Date" 
                  type="date" 
                  value={date} 
                  onChange={(e) => {
                      setDate(e.target.value);
                      if(errors.date) setErrors({...errors, date: ''});
                  }}
                  error={errors.date}
                />
             </div>
             <TextArea 
                label="Content"
                value={content}
                onChange={(e) => {
                    setContent(e.target.value);
                    if(errors.content) setErrors({...errors, content: ''});
                }}
                placeholder="Write your note here..."
                rows={2}
                error={errors.content}
             />
          </div>
          
          <div className="flex flex-col gap-2 w-full md:w-auto">
            <div className="flex gap-1 justify-center md:justify-start">
               {COLORS.map((c) => (
                <button
                  key={c}
                  type="button"
                  className={`w-6 h-6 rounded-full ${c} ${selectedColor === c ? 'ring-2 ring-white scale-110' : 'opacity-50'}`}
                  onClick={() => setSelectedColor(c)}
                />
              ))}
            </div>
            <Button type="submit" className="w-full md:w-auto whitespace-nowrap">
              <StickyNote size={18} /> Add Note
            </Button>
          </div>
        </form>
      </div>

      {/* Notes Grid */}
      <div className="flex-1 overflow-y-auto pr-2">
        {loading ? (
          <div className="text-center text-gray-400 mt-10">Loading notes...</div>
        ) : notes.length === 0 ? (
          <div className="text-center text-gray-400 mt-10">
            No notes yet. Capture your thoughts!
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {notes.map((note) => (
              <div 
                key={note._id} 
                className="group relative bg-slate-800/80 hover:bg-slate-800 backdrop-blur-md border border-white/5 rounded-xl p-5 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-black/40 flex flex-col"
              >
                {/* Highlighted Header Section (Requested Feature) */}
                <div className="flex justify-between items-start mb-3 border-b border-white/10 pb-2">
                  <div className="flex-1">
                    {/* Topic Highlight */}
                    <h3 className={`font-bold text-lg text-transparent bg-clip-text bg-gradient-to-r from-white to-gray-400`}>
                      {note.topic}
                    </h3>
                    
                    {/* Date Highlight */}
                    <div className="flex items-center gap-1 mt-1">
                      <CalendarDays size={12} className="text-gray-400"/>
                      <span className={`text-xs font-mono font-bold px-1.5 py-0.5 rounded ${note.colorTag.replace('bg-', 'text-').replace('500', '400')} bg-white/5`}>
                        {note.date}
                      </span>
                    </div>
                  </div>
                  
                  <div className={`w-3 h-3 rounded-full ${note.colorTag} shadow-[0_0_10px_rgba(0,0,0,0.5)]`} />
                </div>

                <p className="text-gray-300 text-sm whitespace-pre-wrap leading-relaxed flex-1">
                  {note.content}
                </p>

                <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                   <button 
                      onClick={() => handleDelete(note._id)}
                      className="p-1.5 bg-red-500/20 text-red-400 rounded-md hover:bg-red-500 hover:text-white transition-colors"
                   >
                     <Trash2 size={14} />
                   </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Notes;